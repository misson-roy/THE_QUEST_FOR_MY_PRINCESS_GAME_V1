THE QUEST FOR MY PRINCESS — VERSION 1

A mobile-first fantasy adventure vertical slice with story intro, five chapters, combat, dodge, Heartlight, enemies, bosses, dialogue, touch controls and final rescue ending.

PC: WASD/Arrows move; J attack; K dodge; L Heartlight; Enter dialogue; Esc pause.
Mobile: joystick + action buttons.
Open index.html in Chrome/Edge/Firefox. For GitHub Pages, upload index.html and the assets folder (not the ZIP itself).
